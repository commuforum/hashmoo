<TS language="fi" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Valitse hiiren oikealla painikkeella muokataksesi osoitetta tai nimikettä</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Luo uusi osoite</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Uusi</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopioi valittu osoite leikepöydälle</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopioi</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>S&amp;ulje</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Poista valittu osoite listalta</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Anna etsittävä osoite tai tunniste</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Vie auki olevan välilehden tiedot tiedostoon</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Vie</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Poista</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Valitse osoite johon kolikot lähetetään</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Valitse osoite kolikoiden vastaanottamiseen</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>V&amp;alitse</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Lähetysosoitteet</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Vastaanotto-osoitteet</translation>
    </message>
    <message>
        <source>These are your Hashmoo addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Nämä ovat Hashmoo-osoitteesi maksujen lähettämistä varten. Tarkista aina määrä ja vastaanotto-osoite ennen kolikoiden lähettämistä.</translation>
    </message>
    <message>
        <source>These are your Hashmoo addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Tässä ovat Hashmoo vastaanotto-osoitteesi. On suositeltavaa käyttää uutta vastaanotto-osoitetta jokaista lähetystä varten.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Kopioi osoite</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopioi &amp;nimike</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Muokkaa</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Vie osoitelista</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Pilkuilla erotettu tiedosto (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Vienti epäonnistui</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Virhe tallentaessa osoitelistaa kohteeseen %1. Yritä uudelleen.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimikettä)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Tunnuslauseen tekstinsyöttökenttä</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Kirjoita tunnuslause</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Uusi tunnuslause</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Toista uusi tunnuslause</translation>
    </message>
    <message>
        <source>Show password</source>
        <translation>Näytä salasana</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Kirjoita uusi salauslause lompakolle.&lt;br/&gt;Käytä salauslausetta jossa on joko&lt;b&gt;kymmenen tai useampi satunnainen merkki&lt;/b&gt;, tai&lt;b&gt;vähintään kahdeksan sanaa&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Salaa lompakko</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Tämä toiminto vaatii lompakkosi tunnuslauseen sen avaamiseksi</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Avaa lompakko</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Tämä toiminto vaatii lompakkosia tunnuslauseen salauksen purkuun</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Pura lompakon salaus</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Vaihda salasana</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>Syötä vanha ja uusi tunnuslause lompakolle.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Vahvista lompakon salaaminen</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR HASHMOOS&lt;/b&gt;!</source>
        <translation>Varoitus: Jos salaat lompakkosi ja menetät tunnuslauseesi, &lt;b&gt;MENETÄT KAIKKI HASHMOOISI&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Oletko varma että haluat salata lompakkosi?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Lompakko salattiin</translation>
    </message>
    <message>
        <source>Your wallet is now encrypted. Remember that encrypting your wallet cannot fully protect your hashmoos from being stolen by malware infecting your computer.</source>
        <translation>Lompakkosi on nyt salattu. Muistathan, että lompakon salaus ei riitä suojaamaan hashmooejasi viruksen tai muun haittaohjelman tekemältä varkaudelta.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>TÄRKEÄÄ: Kaikki tekemäsi vanhan lompakon varmuuskopiot pitäisi korvata uusilla suojatuilla varmuuskopioilla. Turvallisuussyistä edelliset varmuuskopiot muuttuvat turhiksi, kun aloitat uuden suojatun lompakon käytön.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Lompakon salaaminen epäonnistui</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Lompakon salaaminen epäonnistui sisäisen virheen vuoksi. Lompakkoasi ei salattu.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Annetut salauslauseet eivät täsmää.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Lompakon lukituksen avaaminen epäonnistui</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Annettu salauslause lompakon avaamiseksi oli väärä.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Lompakon salauksen purkaminen epäonnistui</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Lompakon salasana vaihdettiin onnistuneesti.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Varoitus: Caps Lock-painike on päällä!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>IP/Verkon peite</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>Estetty kunnes</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>&amp;Allekirjoita viesti...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synkronoidaan verkon kanssa...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Yleisnäkymä</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Lompakon tilanteen yleiskatsaus</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Rahansiirrot</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Selaa rahansiirtohistoriaa</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>L&amp;opeta</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Sulje ohjelma</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>&amp;Tietoja %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>Näytä tietoa aiheesta %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Tietoja &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Näytä tietoja Qt:ta</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Asetukset...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>Muuta kohteen %1 kokoonpanoasetuksia</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Salaa lompakko...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Varmuuskopioi Lompakko...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Vaihda Tunnuslause...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Avaa &amp;URI...</translation>
    </message>
    <message>
        <source>Wallet:</source>
        <translation>Lompakko:</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>Paina poistaaksesi verkkoyhteysilmaisin käytöstä.</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>Verkkoyhteysmittari pois käytöstä</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>Paina ottaaksesi verkkoyhteysilmaisin uudelleen käyttöön.</translation>
    </message>
    <message>
        <source>Syncing Headers (%1%)...</source>
        <translation>Synkronoidaan Tunnisteita (%1%)...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Ladataan lohkoindeksiä...</translation>
    </message>
    <message>
        <source>Proxy is &lt;b&gt;enabled&lt;/b&gt;: %1</source>
        <translation>Välipalvelin on &lt;b&gt;käytössä&lt;/b&gt;: %1</translation>
    </message>
    <message>
        <source>Send coins to a Hashmoo address</source>
        <translation>Lähetä kolikoita Hashmoo-osoitteeseen</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Varmuuskopioi lompakko toiseen sijaintiin</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Vaihda lompakon salaukseen käytettävä tunnuslause</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Testausikkuna</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Avaa debuggaus- ja diagnostiikkakonsoli</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Varmista &amp;viesti...</translation>
    </message>
    <message>
        <source>Hashmoo</source>
        <translation>Hashmoo</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Lähetä</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Vastaanota</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Näytä / Piilota</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Näytä tai piilota Hashmoo-ikkuna</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Suojaa yksityiset avaimet, jotka kuuluvat lompakkoosi</translation>
    </message>
    <message>
        <source>Sign messages with your Hashmoo addresses to prove you own them</source>
        <translation>Allekirjoita viestisi omalla Hashmoo -osoitteellasi todistaaksesi, että omistat ne</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Hashmoo addresses</source>
        <translation>Varmista, että viestisi on allekirjoitettu määritetyllä Hashmoo -osoitteella</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Tiedosto</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Asetukset</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Apua</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Välilehtipalkki</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and hashmoo: URIs)</source>
        <translation>Pyydä maksuja (Luo QR koodit ja hashmoo: URIt)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Näytä lähettämiseen käytettyjen osoitteiden ja nimien lista</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Näytä vastaanottamiseen käytettyjen osoitteiden ja nimien lista</translation>
    </message>
    <message>
        <source>Open a hashmoo: URI or payment request</source>
        <translation>Avaa hashmoo: URI tai maksupyyntö</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Komentorivin valinnat</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Hashmoo network</source>
        <translation><numerusform>%n aktiivinen yhteys Hashmoo-verkkoon</numerusform><numerusform>%n aktiivista yhteyttä Hashmoo-verkkoon</numerusform></translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>Ladataan lohkoindeksiä...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>Käsitellään lohkoja levyllä...</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n block(s) of transaction history.</source>
        <translation><numerusform>Käsitelty %n lohko rahansiirtohistoriasta.</numerusform><numerusform>Käsitelty %n lohkoa rahansiirtohistoriasta.</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 jäljessä</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Viimeisin vastaanotettu lohko tuotettu %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Tämän jälkeiset rahansiirrot eivät ole vielä näkyvissä.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Tietoa</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Rahansiirtohistoria on ajan tasalla</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Hashmoo command-line options</source>
        <translation>Näytä %1 ohjeet saadaksesi listan mahdollisista Hashmooin komentorivivalinnoista</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation>oletuslompakko</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Ikkuna</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Pienennä</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Palauta</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation>Pääikkuna</translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>%1-asiakas</translation>
    </message>
    <message>
        <source>Connecting to peers...</source>
        <translation>Yhdistetään vertaisiin...</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Saavutetaan verkkoa...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>Päivämäärä: %1
</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>Määrä: %1
</translation>
    </message>
    <message>
        <source>Wallet: %1
</source>
        <translation>Lompakko: %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>Tyyppi: %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>Nimike: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>Osoite: %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Lähetetyt rahansiirrot</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Saapuva rahansiirto</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;enabled&lt;/b&gt;</source>
        <translation>HD avaimen generointi on &lt;b&gt;päällä&lt;/b&gt;</translation>
    </message>
    <message>
        <source>HD key generation is &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>HD avaimen generointi on &lt;/b&gt;pois päältä&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Private key &lt;b&gt;disabled&lt;/b&gt;</source>
        <translation>Yksityisavain &lt;b&gt;ei käytössä&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Lompakko on &lt;b&gt;salattu&lt;/b&gt; ja tällä hetkellä &lt;b&gt;avoinna&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Lompakko on &lt;b&gt;salattu&lt;/b&gt; ja tällä hetkellä &lt;b&gt;lukittuna&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Hashmoo can no longer continue safely and will quit.</source>
        <translation>Peruuttamaton virhe on tapahtunut. Hashmoo ei voi enää jatkaa turvallisesti ja sammutetaan.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Kolikoiden valinta</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Tavuja:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Palkkio:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Tomu:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Palkkion jälkeen:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Vaihtoraha:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(epä)valitse kaikki</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Puurakenne</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listarakenne</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Vastaanotettu nimikkeellä</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Vastaanotettu osoitteella</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Vahvistuksia</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Vahvistettu</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopioi osoite</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopioi nimike</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopioi transaktion ID</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Lukitse käyttämättömät</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Avaa käyttämättömien lukitus</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopioi lukumäärä</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopioi rahansiirtokulu</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopioi rahansiirtokulun jälkeen</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopioi tavut</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopioi tomu</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopioi vaihtorahat</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 lukittu)</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>kyllä</translation>
    </message>
    <message>
        <source>no</source>
        <translation>ei</translation>
    </message>
    <message>
        <source>This label turns red if any recipient receives an amount smaller than the current dust threshold.</source>
        <translation>Tämä nimike muuttuu punaiseksi, jos jokin vastaanottajista on saamassa tämänhetkistä tomun rajaa pienemmän summan.</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation>Saattaa vaihdella +/- %1 satoshia per syöte.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimikettä)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>Vaihda %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(vaihtoraha)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Muokkaa osoitetta</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Nimi</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Tähän osoitteeseen liitetty nimi</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Osoite liitettynä tähän osoitekirjan alkioon. Tämä voidaan muokata vain lähetysosoitteissa.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Osoite</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Uusi lähetysosoite</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Muokkaa vastaanottavaa osoitetta</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Muokkaa lähettävää osoitetta</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Hashmoo address.</source>
        <translation>Antamasi osoite "%1" ei ole kelvollinen Hashmoo-osoite.</translation>
    </message>
    <message>
        <source>Address "%1" already exists as a receiving address with label "%2" and so cannot be added as a sending address.</source>
        <translation>Osoite "%1" on jo vastaanotto-osoitteena nimellä "%2", joten sitä ei voi lisätä lähetysosoitteeksi.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book with label "%2".</source>
        <translation>Syötetty osoite "%1" on jo osoitekirjassa nimellä "%2".</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Lompakkoa ei voitu avata.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Uuden avaimen luonti epäonnistui.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Luodaan uusi kansio.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Hakemisto on jo olemassa. Lisää %1 jos tarkoitus on luoda hakemisto tänne.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Polku on jo olemassa, eikä se ole kansio.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Ei voida luoda data-hakemistoa tänne.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>versio</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Tietoja %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Komentorivi parametrit</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Tervetuloa</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation>Tervetuloa %1 pariin.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>Tämä on ensimmäinen kerta, kun %1 on käynnistetty, joten voit valita data-hakemiston paikan.</translation>
    </message>
    <message>
        <source>When you click OK, %1 will begin to download and process the full %4 block chain (%2GB) starting with the earliest transactions in %3 when %4 initially launched.</source>
        <translation>Kun valitset OK, %1 aloittaa lataamaan ja käsittelemään koko %4 lohkoketjua (%2GB) aloittaen ensimmäisestä siirrosta %3 jolloin %4 käynnistettiin ensimmäistä kertaa.</translation>
    </message>
    <message>
        <source>This initial synchronisation is very demanding, and may expose hardware problems with your computer that had previously gone unnoticed. Each time you run %1, it will continue downloading where it left off.</source>
        <translation>Tämä alustava synkronointi on erittäin vaativa ja saattaa tuoda esiin laiteongelmia, joita ei aikaisemmin ole havaittu. Aina kun ajat %1:n, jatketaan siitä kohdasta, mihin viimeksi jäätiin.</translation>
    </message>
    <message>
        <source>If you have chosen to limit block chain storage (pruning), the historical data must still be downloaded and processed, but will be deleted afterward to keep your disk usage low.</source>
        <translation>Vaikka olisitkin valinnut rajoittaa lohkoketjun tallennustilaa (karsinnalla), täytyy historiatiedot silti ladata ja käsitellä, mutta ne poistetaan jälkikäteen levytilan säästämiseksi.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Käytä oletuskansiota</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Määritä oma kansio:</translation>
    </message>
    <message>
        <source>Hashmoo</source>
        <translation>Hashmoo</translation>
    </message>
    <message>
        <source>At least %1 GB of data will be stored in this directory, and it will grow over time.</source>
        <translation>Ainakin %1 GB tietoa varastoidaan tähän hakemistoon ja tarve kasvaa ajan myötä.</translation>
    </message>
    <message>
        <source>Approximately %1 GB of data will be stored in this directory.</source>
        <translation>Noin %1 GB tietoa varastoidaan tähän hakemistoon.</translation>
    </message>
    <message>
        <source>%1 will download and store a copy of the Hashmoo block chain.</source>
        <translation>%1 lataa ja tallentaa kopion Hashmooin lohkoketjusta.</translation>
    </message>
    <message>
        <source>The wallet will also be stored in this directory.</source>
        <translation>Lompakko tallennetaan myös tähän hakemistoon.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Virhe: Annettu datahakemistoa "%1" ei voida luoda.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message numerus="yes">
        <source>%n GB of free space available</source>
        <translation><numerusform>%n GB tilaa vapaana</numerusform><numerusform>%n GB tilaa vapaana</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>(of %n GB needed)</source>
        <translation><numerusform>(tarvitaan %n GB)</numerusform><numerusform>(tarvitaan %n GB)</numerusform></translation>
    </message>
</context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Recent transactions may not yet be visible, and therefore your wallet's balance might be incorrect. This information will be correct once your wallet has finished synchronizing with the hashmoo network, as detailed below.</source>
        <translation>Viimeiset tapahtumat eivät välttämättä vielä näy, joten lompakkosi saldo voi olla virheellinen. Tieto korjautuu, kunhan lompakkosi synkronointi hashmoo-verkon kanssa on päättynyt. Tiedot näkyvät alla.</translation>
    </message>
    <message>
        <source>Attempting to spend hashmoos that are affected by not-yet-displayed transactions will not be accepted by the network.</source>
        <translation>Verkko ei tule hyväksymään sellaisten hashmooien käyttämistä, jotka liittyvät vielä näkymättömissä oleviin siirtoihin.</translation>
    </message>
    <message>
        <source>Number of blocks left</source>
        <translation>Lohkoja jäljellä</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>Tunnistamaton..</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Viimeisimmän lohkon aika</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation>Edistyminen</translation>
    </message>
    <message>
        <source>Progress increase per hour</source>
        <translation>Edistymisen kasvu tunnissa</translation>
    </message>
    <message>
        <source>calculating...</source>
        <translation>lasketaan..</translation>
    </message>
    <message>
        <source>Estimated time left until synced</source>
        <translation>Arvioitu jäljellä oleva aika, kunnes synkronoitu</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Piilota</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Avaa URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Avaa maksupyyntö URI:sta tai tiedostosta</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Valitse maksupyynnön tiedosto</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Valitse maksypyynnön tiedosto avattavaksi</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Yleiset</translation>
    </message>
    <message>
        <source>Automatically start %1 after logging in to the system.</source>
        <translation>Käynnistä %1 automaattisesti järjestelmään kirjautumisen jälkeen.</translation>
    </message>
    <message>
        <source>&amp;Start %1 on system login</source>
        <translation>&amp;Käynnistä %1 järjestelmään kirjautuessa</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>&amp;Tietokannan välimuistin koko</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Säikeiden määrä skriptien &amp;varmistuksessa</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP osoite proxille (esim. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Shows if the supplied default SOCKS5 proxy is used to reach peers via this network type.</source>
        <translation>Ilmoittaa, mikäli oletetettua SOCKS5-välityspalvelinta käytetään vertaisten tavoittamiseen tämän verkkotyypin kautta.</translation>
    </message>
    <message>
        <source>Use separate SOCKS&amp;5 proxy to reach peers via Tor hidden services:</source>
        <translation>Käytä SOCKS&amp;5-välityspalvelinta tavoittamaan Tor-verkon piilotetut palvelut:</translation>
    </message>
    <message>
        <source>Hide the icon from the system tray.</source>
        <translation>Piilota kuvake järjestelmäpalkista.</translation>
    </message>
    <message>
        <source>&amp;Hide tray icon</source>
        <translation>&amp;Piilota tehtäväpalkin kuvake</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Exit in the menu.</source>
        <translation>Minimoi ikkuna ohjelman sulkemisen sijasta kun ikkuna suljetaan. Kun tämä asetus on käytössä, ohjelma suljetaan vain valittaessa valikosta Poistu.</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Ulkopuoliset URL-osoitteet (esim. block explorer,) jotka esiintyvät siirrot-välilehdellä valikossa. %s URL-osoitteessa korvataan siirtotunnuksella. Useampi URL-osoite on eroteltu pystyviivalla |.</translation>
    </message>
    <message>
        <source>Open the %1 configuration file from the working directory.</source>
        <translation>Avaa %1 asetustiedosto työhakemistosta.</translation>
    </message>
    <message>
        <source>Open Configuration File</source>
        <translation>Avaa asetustiedosto.</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Palauta kaikki asetukset takaisin alkuperäisiksi.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Palauta asetukset</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Verkko</translation>
    </message>
    <message>
        <source>Disables some advanced features but all blocks will still be fully validated. Reverting this setting requires re-downloading the entire blockchain. Actual disk usage may be somewhat higher.</source>
        <translation>Jättää pois joitain edistyneitä ominaisuuksia, mutta silti varmistaa kaikki lohkot kokonaan. Tämän asetuksen muutto vaatii koko lohkoketjun uudelleen lataamisen. Levyn käyttöaste saattaa olla hiukan suurempaa.</translation>
    </message>
    <message>
        <source>Prune &amp;block storage to</source>
        <translation>Karsi lohkovaraston kooksi</translation>
    </message>
    <message>
        <source>GB</source>
        <translation>Gt</translation>
    </message>
    <message>
        <source>Reverting this setting requires re-downloading the entire blockchain.</source>
        <translation>Tämän asetuksen muuttaminen vaatii koko lohkoketjun uudelleenlataamista.</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = auto, &lt;0 = jätä näin monta ydintä vapaaksi)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>&amp;Lompakko</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Expertti</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Ota käytöön &amp;Kolikkokontrolli-ominaisuudet</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Jos poistat varmistamattomien vaihtorahojen käytön, rahansiirron vaihtorahaa ei voida käyttää ennen vähintään yhtä varmistusta. Tämä vaikuttaa myös kuinka taseesi lasketaan.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Käytä varmistamattomia vaihtorahoja</translation>
    </message>
    <message>
        <source>Automatically open the Hashmoo client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Avaa Hashmoo-asiakasohjelman portti reitittimellä automaattisesti. Tämä toimii vain, jos reitittimesi tukee UPnP:tä ja se on käytössä.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Portin uudelleenohjaus &amp;UPnP:llä</translation>
    </message>
    <message>
        <source>Accept connections from outside.</source>
        <translation>Hyväksy yhteysiä ulkopuolelta</translation>
    </message>
    <message>
        <source>Allow incomin&amp;g connections</source>
        <translation>Hyväksy sisääntulevia yhteyksiä</translation>
    </message>
    <message>
        <source>Connect to the Hashmoo network through a SOCKS5 proxy.</source>
        <translation>Yhdistä Hashmoo-verkkoon SOCKS5-välityspalvelimen kautta.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Yhdistä SOCKS5-välityspalvelimen kautta (oletus välityspalvelin):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxyn &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Portti</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Proxyn Portti (esim. 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>Vertaisten saavuttamiseen käytettävät verkkotyypit:</translation>
    </message>
    <message>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <source>Tor</source>
        <translation>Tor</translation>
    </message>
    <message>
        <source>Connect to the Hashmoo network through a separate SOCKS5 proxy for Tor hidden services.</source>
        <translation>Yhdistä Hashmoo-verkkoon erillisen SOCKS5-välityspalvelimen kautta piilotettuja Tor-palveluja varten.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Ikkuna</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Näytä ainoastaan ilmaisinalueella ikkunan pienentämisen jälkeen.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Pienennä ilmaisinalueelle työkalurivin sijasta</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>P&amp;ienennä suljettaessa</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Käyttöliittymä</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Käyttöliittymän kieli</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting %1.</source>
        <translation>Tässä voit määritellä käyttöliittymän kielen. Muutokset astuvat voimaan seuraavan kerran, kun %1 käynnistetään.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Yksikkö jona hashmoo-määrät näytetään</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Valitse mitä yksikköä käytetään ensisijaisesti hashmoo-määrien näyttämiseen.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Näytetäänkö kolikkokontrollin ominaisuuksia vai ei</translation>
    </message>
    <message>
        <source>&amp;Third party transaction URLs</source>
        <translation>&amp;Kolmannen osapuolen rahansiirto URL:t</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Peruuta</translation>
    </message>
    <message>
        <source>default</source>
        <translation>oletus</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ei mitään</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Varmista asetusten palautus</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Ohjelman uudelleenkäynnistys aktivoi muutokset.</translation>
    </message>
    <message>
        <source>Client will be shut down. Do you want to proceed?</source>
        <translation>Asiakasohjelma sammutetaan. Haluatko jatkaa?</translation>
    </message>
    <message>
        <source>Configuration options</source>
        <translation>Kokoonpanoasetukset</translation>
    </message>
    <message>
        <source>The configuration file is used to specify advanced user options which override GUI settings. Additionally, any command-line options will override this configuration file.</source>
        <translation>Asetustiedostoa käytetään määrittämään kokeneen käyttäjän lisävalintoja, jotka ylikirjoittavat graafisen käyttöliittymän asetukset. Lisäksi komentokehoitteen valinnat ylikirjoittavat kyseisen asetustiedoston.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <source>The configuration file could not be opened.</source>
        <translation>Asetustiedostoa ei voitu avata.</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Tämä muutos vaatii ohjelman uudelleenkäynnistyksen.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Antamasi proxy-osoite on virheellinen.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Hashmoo network after a connection is established, but this process has not completed yet.</source>
        <translation>Näytetyt tiedot eivät välttämättä ole ajantasalla. Lompakkosi synkronoituu Hashmoo-verkon kanssa automaattisesti yhteyden muodostamisen jälkeen, mutta synkronointi on vielä meneillään.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Seuranta:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Käytettävissä:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Nykyinen käytettävissä oleva tase</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Odotetaan:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Varmistamattomien rahansiirtojen summa, jota ei lasketa käytettävissä olevaan taseeseen.</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Epäkypsää:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Louhittu saldo, joka ei ole vielä kypsynyt</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Saldot</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Yhteensä:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Tililläsi tällä hetkellä olevien Hashmooien määrä</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Nykyinen tase seurantaosoitetteissa</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Käytettävissä:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Viimeisimmät rahansiirrot</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Vahvistamattomat rahansiirrot vain katseltaviin osoitteisiin</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>Louhittu, ei vielä kypsynyt saldo vain katseltavissa osoitteissa</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Nykyinen tase seurantaosoitetteissa</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>Maksupyyntövirhe</translation>
    </message>
    <message>
        <source>Cannot start hashmoo: click-to-pay handler</source>
        <translation>Hashmooia ei voi käynnistää: klikkaa-maksaaksesi -käsittelijän virhe</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>URI käsittely</translation>
    </message>
    <message>
        <source>'hashmoo://' is not a valid URI. Use 'hashmoo:' instead.</source>
        <translation>'hashmoo://' ei ole kelvollinen URI. Käytä 'hashmoo:' sen sijaan.</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Maksupyynnön haku URL on virheellinen: %1</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Virheellinen maksuosoite %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Hashmoo address or malformed URI parameters.</source>
        <translation>URIa ei voitu jäsentää! Tämä voi johtua virheellisestä Hashmoo-osoitteesta tai väärin muotoilluista URI parametreista.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Maksupyynnön tiedoston käsittely</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Maksupyyntötiedostoa ei voi lukea! Tämä saattaa johtua epäkelvosta maksupyyntötiedostosta.</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Maksupyyntö hylätty</translation>
    </message>
    <message>
        <source>Payment request network doesn't match client network.</source>
        <translation>Maksupyyntoverkko ei täsmää asiakasohjelman verkon kanssa.</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Maksupyyntö vanhentui.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>Maksupyyntöä ei ole alustettu.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Varmistamattomia maksupyyntöjä kustomoituun maksupalveluun ei tueta.</translation>
    </message>
    <message>
        <source>Invalid payment request.</source>
        <translation>Virheellinen maksupyyntö.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Maksupyyntö %1 on liian pieni (kohdellaan tomuna).</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Maksupalautus %1:sta</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>Maksupyyntö %1 on liian suuri (%2 tavua, sallittu %3 tavua).</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Virhe kommunikoidessa %1n kanssa: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>Maksupyyntöä ei voida jäsentää!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Virheellinen vastaus palvelimelta %1</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Tietoverkon pyyntövirhe</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Rahansiirto tunnistettu</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Käyttöliittymä</translation>
    </message>
    <message>
        <source>Node/Service</source>
        <translation>Noodi/Palvelu</translation>
    </message>
    <message>
        <source>NodeId</source>
        <translation>NodeId</translation>
    </message>
    <message>
        <source>Ping</source>
        <translation>Vasteaika</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Lähetetyt</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Vastaanotetut</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>Enter a Hashmoo address (e.g. %1)</source>
        <translation>Syötä Hashmoo-osoite (esim. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 d</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei yhtään</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 ms</translation>
    </message>
    <message numerus="yes">
        <source>%n second(s)</source>
        <translation><numerusform>%n sekunti</numerusform><numerusform>%n sekuntia</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n minute(s)</source>
        <translation><numerusform>%n minuutti</numerusform><numerusform>%n minuuttia</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n tunti</numerusform><numerusform>%n tuntia</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n päivä</numerusform><numerusform>%n päivää</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n viikko</numerusform><numerusform>%n viikkoa</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 ja %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n vuosi</numerusform><numerusform>%n vuotta</numerusform></translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 didn't yet exit safely...</source>
        <translation>%1 ei vielä sulkeutunut turvallisesti...</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>tuntematon</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Error parsing command line arguments: %1.</source>
        <translation>Virhe käsitellessä komentorivin valintaa: %1.</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" does not exist.</source>
        <translation>Virhe: Annettua data-hakemistoa "%1" ei ole olemassa.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1.</source>
        <translation>Virhe: Asetustiedostoa ei voida käsitellä: %1.</translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation>Virhe: %1</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Tallenna kuva</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Kopioi kuva</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Tallenna QR-koodi</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG kuva (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>Ei saatavilla</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Pääteohjelman versio</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>T&amp;ietoa</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>&amp;Debug-ikkuna</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Yleinen</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Käyttää BerkeleyDB-versiota</translation>
    </message>
    <message>
        <source>Datadir</source>
        <translation>Data-hakemisto</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Käynnistysaika</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Verkko</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Yhteyksien lukumäärä</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Lohkoketju</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Nykyinen Lohkojen määrä</translation>
    </message>
    <message>
        <source>Memory Pool</source>
        <translation>Muistiallas</translation>
    </message>
    <message>
        <source>Current number of transactions</source>
        <translation>Tämänhetkinen rahansiirtojen määrä</translation>
    </message>
    <message>
        <source>Memory usage</source>
        <translation>Muistin käyttö</translation>
    </message>
    <message>
        <source>Wallet: </source>
        <translation>Lompakko:</translation>
    </message>
    <message>
        <source>&amp;Reset</source>
        <translation>&amp;Nollaa</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Vastaanotetut</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Lähetetyt</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Vertaiset</translation>
    </message>
    <message>
        <source>Banned peers</source>
        <translation>Estetyt vertaiset</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Valitse vertainen eriteltyjä tietoja varten.</translation>
    </message>
    <message>
        <source>Whitelisted</source>
        <translation>Sallittu</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <source>Starting Block</source>
        <translation>Alkaen lohkosta</translation>
    </message>
    <message>
        <source>Synced Headers</source>
        <translation>Synkronoidut ylätunnisteet</translation>
    </message>
    <message>
        <source>Synced Blocks</source>
        <translation>Synkronoidut lohkot</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Käyttöliittymä</translation>
    </message>
    <message>
        <source>Open the %1 debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Avaa %1 -debug-loki tämänhetkisestä data-hakemistosta. Tämä voi viedä muutaman sekunnin suurille lokitiedostoille.</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>Pienennä fontin kokoa</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>Suurenna fontin kokoa</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Palvelut</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Panna-pisteytys</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Yhteysaika</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Viimeisin lähetetty</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Viimeisin vastaanotettu</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Vasteaika</translation>
    </message>
    <message>
        <source>The duration of a currently outstanding ping.</source>
        <translation>Tämänhetkisen merkittävän yhteyskokeilun kesto.</translation>
    </message>
    <message>
        <source>Ping Wait</source>
        <translation>Yhteyskokeilun odotus</translation>
    </message>
    <message>
        <source>Min Ping</source>
        <translation>Pienin vasteaika</translation>
    </message>
    <message>
        <source>Time Offset</source>
        <translation>Ajan poikkeama</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Viimeisimmän lohkon aika</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Avaa</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsoli</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Verkkoliikenne</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Yhteensä</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Sisään:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Ulos:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debug lokitiedosto</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Tyhjennä konsoli</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;tunti</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp;päivä</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp;viikko</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp;vuosi</translation>
    </message>
    <message>
        <source>&amp;Disconnect</source>
        <translation>&amp;Katkaise yhteys</translation>
    </message>
    <message>
        <source>Ban for</source>
        <translation>Estä </translation>
    </message>
    <message>
        <source>&amp;Unban</source>
        <translation>&amp;Poista esto</translation>
    </message>
    <message>
        <source>Welcome to the %1 RPC console.</source>
        <translation>Tervetuloa %1 RPC-konsoliin.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and %1 to clear screen.</source>
        <translation>Käytä nuolia ylös ja alas selataksesi historiaa, sekä %1 tyhjentääkseksi ruudun.</translation>
    </message>
    <message>
        <source>Type %1 for an overview of available commands.</source>
        <translation>Kirjoita %1 nähdäksesi yleiskatsauksen käytettävissä olevista komennoista.</translation>
    </message>
    <message>
        <source>For more information on using this console type %1.</source>
        <translation>Lisätietoja konsolin käytöstä saat kirjoittamalla %1.</translation>
    </message>
    <message>
        <source>WARNING: Scammers have been active, telling users to type commands here, stealing their wallet contents. Do not use this console without fully understanding the ramifications of a command.</source>
        <translation>VAROITUS: aktiiviset huijarit neuvovat kirjoittamaan komentoja tähän komentoriviin, varastaen lompakkosi sisällön. Älä käytä komentoriviä ilman täyttä ymmärrystä kirjoittamasi komennon toiminnasta.</translation>
    </message>
    <message>
        <source>Network activity disabled</source>
        <translation>Verkkoliikenne pysäytetty</translation>
    </message>
    <message>
        <source>Executing command without any wallet</source>
        <translation>Suoritetaan komento ilman lomakkoa</translation>
    </message>
    <message>
        <source>(node id: %1)</source>
        <translation>(solmukohdan id: %1)</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>%1 kautta</translation>
    </message>
    <message>
        <source>never</source>
        <translation>ei koskaan</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Sisääntuleva</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Ulosmenevä</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ei</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Tuntematon</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Määrä</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Nimi:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Viesti:</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Hashmoo network.</source>
        <translation>Valinnainen viesti liitetään maksupyyntöön ja näytetään avattaessa. Viestiä ei lähetetä Hashmoo-verkkoon.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Valinnainen nimi liitetään vastaanottavaan osoitteeseen.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Käytä lomaketta maksupyyntöihin. Kaikki kentät ovat &lt;b&gt;valinnaisia&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Valinnainen pyyntömäärä. Jätä tyhjäksi tai nollaksi jos et pyydä tiettyä määrää.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Tyhjennä lomakkeen kaikki kentät.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Native segwit addresses (aka Bech32 or BIP-173) reduce your transaction fees later on and offer better protection against typos, but old wallets don't support them. When unchecked, an address compatible with older wallets will be created instead.</source>
        <translation>Natiivi segwit osoite (nk. Bech32 tai BIP173) rajoittaa siirtomaksuja myöhemmin ja tarjoaa paremman suojan kirjoitusvihreitä vastaan, mutta vanhat lompakot eivät tue ominaisuutta. Jos tätä ei valita, luodaan vanhojen lompakoiden kanssa yhteensopivia osoitteita.</translation>
    </message>
    <message>
        <source>Generate native segwit (Bech32) address</source>
        <translation>Luo natiivi segwit (Bech32) -osoite</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Pyydettyjen maksujen historia</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Vastaanota maksu</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Näytä valittu pyyntö (sama toiminta kuin alkion tuplaklikkaus)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Poista valitut alkiot listasta</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Copy URI</source>
        <translation>Kopioi URI</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopioi nimike</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Kopioi viesti</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-koodi</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopioi &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopioi &amp;Osoite</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Tallenna kuva</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Pyydä maksua osoitteeseen %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Maksutiedot</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Lompakko</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Tuloksen URI on liian pitkä, yritä lyhentää otsikon tai viestin tekstiä.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Virhe käännettäessä URI:a QR-koodiksi.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimikettä)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(ei viestiä)</translation>
    </message>
    <message>
        <source>(no amount requested)</source>
        <translation>(ei pyydettyä määrää)</translation>
    </message>
    <message>
        <source>Requested</source>
        <translation>Pyydetty</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Lähetä kolikoita</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Kolikkokontrolli ominaisuudet</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Sisääntulot...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automaattisesti valitut</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Lompakon saldo ei riitä!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Tavuja:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Palkkio:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Palkkion jälkeen:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Vaihtoraha:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Jos tämä aktivoidaan mutta vaihtorahan osoite on tyhjä tai virheellinen, vaihtoraha tullaan lähettämään uuteen luotuun osoitteeseen.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Kustomoitu vaihtorahan osoite</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Rahansiirtokulu:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Valitse...</translation>
    </message>
    <message>
        <source>Using the fallbackfee can result in sending a transaction that will take several hours or days (or never) to confirm. Consider choosing your fee manually or wait until you have validated the complete chain.</source>
        <translation>Fallbackfeen käyttö voi johtaa useita tunteja, päiviä (tai loputtomiin) kestävän siirron lähettämiseen. Harkitse palkkion valitsemista itse tai odota kunnes koko ketju on vahvistettu.</translation>
    </message>
    <message>
        <source>Warning: Fee estimation is currently not possible.</source>
        <translation>Varoitus: Kulujen arviointi ei ole juuri nyt mahdollista.</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>pudota kulujen asetukset</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>per kilotavu</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Piilota</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Suositeltu:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Muokattu:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation>(Älykästä rahansiirtokulua ei ole vielä alustettu. Tähän kuluu yleensä aikaa muutaman lohkon verran...)</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Lähetä usealla vastaanottajalle samanaikaisesti</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Lisää &amp;Vastaanottaja</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Tyhjennä lomakkeen kaikki kentät.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Tomu:</translation>
    </message>
    <message>
        <source>Confirmation time target:</source>
        <translation>Vahvistusajan tavoite:</translation>
    </message>
    <message>
        <source>Enable Replace-By-Fee</source>
        <translation>Käytä Replace-By-Fee:tä</translation>
    </message>
    <message>
        <source>With Replace-By-Fee (BIP-125) you can increase a transaction's fee after it is sent. Without this, a higher fee may be recommended to compensate for increased transaction delay risk.</source>
        <translation>Replace-By-Fee:tä (BIP-125) käyttämällä voit korottaa siirtotapahtuman palkkiota sen lähettämisen jälkeen. Ilman tätä saatetaan suositella käyttämään suurempaa palkkiota kompensoimaan viiveen kasvamisen riskiä.</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Tyhjennnä Kaikki</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balanssi:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Vahvista lähetys</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Lähetä</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopioi lukumäärä</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopioi rahansiirtokulu</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopioi rahansiirtokulun jälkeen</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopioi tavut</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Kopioi tomu</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopioi vaihtorahat</translation>
    </message>
    <message>
        <source>%1 (%2 blocks)</source>
        <translation>%1 (%2 lohkoa)</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 to %2</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Oletko varma, että haluat lähettää?</translation>
    </message>
    <message>
        <source>or</source>
        <translation>tai</translation>
    </message>
    <message>
        <source>You can increase the fee later (signals Replace-By-Fee, BIP-125).</source>
        <translation>Voit korottaa palkkiota myöhemmin (osoittaa Replace-By-Fee:tä, BIP-125).</translation>
    </message>
    <message>
        <source>from wallet %1</source>
        <translation>lompakosta %1</translation>
    </message>
    <message>
        <source>Please, review your transaction.</source>
        <translation>Tarkistathan siirtosi.</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Siirtokulu</translation>
    </message>
    <message>
        <source>Total Amount</source>
        <translation>Yhteensä</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Vahvista kolikoiden lähetys</translation>
    </message>
    <message>
        <source>The recipient address is not valid. Please recheck.</source>
        <translation>Vastaanottajan osoite ei ole kelvollinen. Tarkista osoite.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Maksettavan määrän täytyy olla suurempi kuin 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Määrä ylittää tilisi saldon.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Kokonaismäärä ylittää saldosi kun %1 siirtomaksu lisätään summaan.</translation>
    </message>
    <message>
        <source>Duplicate address found: addresses should only be used once each.</source>
        <translation>Osoite esiintyy useaan kertaan: osoitteita tulisi käyttää vain kerran kutakin.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Rahansiirron luonti epäonnistui!</translation>
    </message>
    <message>
        <source>The transaction was rejected with the following reason: %1</source>
        <translation>Siirto hylättiin seuraavasta syystä: %1</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an absurdly high fee.</source>
        <translation>%1:tä ja korkeampaa siirtokulua pidetään mielettömän korkeana.</translation>
    </message>
    <message>
        <source>Payment request expired.</source>
        <translation>Maksupyyntö vanhentui.</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation><numerusform>Vahvistuminen alkaa arviolta %n lohkon sisällä.</numerusform><numerusform>Vahvistuminen alkaa arviolta %n lohkon sisällä.</numerusform></translation>
    </message>
    <message>
        <source>Warning: Invalid Hashmoo address</source>
        <translation>Varoitus: Virheellinen Hashmoo-osoite </translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Varoitus: Tuntematon vaihtorahan osoite</translation>
    </message>
    <message>
        <source>Confirm custom change address</source>
        <translation>Vahvista kustomoitu vaihtorahan osoite</translation>
    </message>
    <message>
        <source>The address you selected for change is not part of this wallet. Any or all funds in your wallet may be sent to this address. Are you sure?</source>
        <translation>Valitsemasi vaihtorahan osoite ei kuulu tähän lompakkoon. Osa tai kaikki varoista lompakossasi voidaan lähettää tähän osoitteeseen. Oletko varma?</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimikettä)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>M&amp;äärä:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Maksun saaja:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Nimi:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Valitse aikaisemmin käytetty osoite</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Tämä on normaali maksu.</translation>
    </message>
    <message>
        <source>The Hashmoo address to send the payment to</source>
        <translation>Hashmoo-osoite johon maksu lähetetään</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Liitä osoite leikepöydältä</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Poista tämä alkio</translation>
    </message>
    <message>
        <source>The fee will be deducted from the amount being sent. The recipient will receive less hashmoos than you enter in the amount field. If multiple recipients are selected, the fee is split equally.</source>
        <translation>Kulu vähennetään lähetettävästä määrästä. Saaja vastaanottaa vähemmän hashmooeja kuin merkitset Määrä-kenttään. Jos saajia on monia, kulu jaetaan tasan.</translation>
    </message>
    <message>
        <source>S&amp;ubtract fee from amount</source>
        <translation>V&amp;ähennä maksukulu määrästä</translation>
    </message>
    <message>
        <source>Use available balance</source>
        <translation>Käytä saatavilla oleva saldo</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Viesti:</translation>
    </message>
    <message>
        <source>This is an unauthenticated payment request.</source>
        <translation>Tämä on todentamaton maksupyyntö.</translation>
    </message>
    <message>
        <source>This is an authenticated payment request.</source>
        <translation>Tämä on todennettu maksupyyntö.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Aseta nimi tälle osoitteelle lisätäksesi sen käytettyjen osoitteiden listalle.</translation>
    </message>
    <message>
        <source>A message that was attached to the hashmoo: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Hashmoo network.</source>
        <translation>Viesti joka liitettiin hashmoo: URI:iin tallennetaan rahansiirtoon viitteeksi. Tätä viestiä ei lähetetä Hashmoo-verkkoon.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Saaja:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Muistio:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Syötä tälle osoitteelle nimi lisätäksesi sen osoitekirjaan</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>Kyllä</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>%1 is shutting down...</source>
        <translation>%1 sulkeutuu...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Älä sammuta tietokonetta ennenkuin tämä ikkuna katoaa.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Allekirjoitukset - Allekirjoita / Varmista viesti</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Allekirjoita viesti</translation>
    </message>
    <message>
        <source>You can sign messages/agreements with your addresses to prove you can receive hashmoos sent to them. Be careful not to sign anything vague or random, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Voit allekirjoittaa viestit / sopimukset omalla osoitteellasi todistaaksesi että voit vastaanottaa siihen lähetetyt hashmooit. Varo allekirjoittamasta mitään epämääräistä, sillä phishing-hyökkääjät voivat huijata sinua luovuttamaan henkilöllisyytesi allekirjoituksella. Allekirjoita ainoastaan täysin yksityiskohtainen selvitys siitä, mihin olet sitoutumassa.</translation>
    </message>
    <message>
        <source>The Hashmoo address to sign the message with</source>
        <translation>Hashmoo-osoite jolla viesti allekirjoitetaan</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Valitse aikaisemmin käytetty osoite</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Liitä osoite leikepöydältä</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Kirjoita tähän viesti minkä haluat allekirjoittaa</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Allekirjoitus</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopioi tämänhetkinen allekirjoitus leikepöydälle</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Hashmoo address</source>
        <translation>Allekirjoita viesti todistaaksesi, että omistat tämän Hashmoo-osoitteen</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Allekirjoita &amp;viesti</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Tyhjennä kaikki allekirjoita-viesti-kentät</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Tyhjennnä Kaikki</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Varmista viesti</translation>
    </message>
    <message>
        <source>Enter the receiver's address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack. Note that this only proves the signing party receives with the address, it cannot prove sendership of any transaction!</source>
        <translation>Syötä vastaanottajan osoite, viesti ja allekirjoitus (varmista että kopioit rivinvaihdot, välilyönnit, sarkaimet yms. täsmälleen) alle vahvistaaksesi viestin. Varo lukemasta allekirjoitukseen enempää kuin mitä viestissä itsessään on välttääksesi man-in-the-middle -hyökkäyksiltä. Huomaa, että tämä todentaa ainoastaan allekirjoittavan vastaanottajan osoitteen, tämä ei voi todentaa minkään tapahtuman lähettäjää!</translation>
    </message>
    <message>
        <source>The Hashmoo address the message was signed with</source>
        <translation>Hashmoo-osoite jolla viesti on allekirjoitettu</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Hashmoo address</source>
        <translation>Tarkista viestin allekirjoitus varmistaaksesi, että se allekirjoitettiin tietyllä Hashmoo-osoitteella</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Varmista &amp;viesti...</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Tyhjennä kaikki varmista-viesti-kentät</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>Valitse "Allekirjoita Viesti" luodaksesi allekirjoituksen.</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Syötetty osoite on virheellinen.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Tarkista osoite ja yritä uudelleen.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Syötetty osoite ei viittaa tunnettuun avaimeen.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Lompakon avaaminen peruttiin.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Yksityistä avainta syötetylle osoitteelle ei ole saatavilla.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Viestin allekirjoitus epäonnistui.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Viesti allekirjoitettu.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Allekirjoitusta ei pystytty tulkitsemaan.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Tarkista allekirjoitus ja yritä uudelleen.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Allekirjoitus ei täsmää viestin tiivisteeseen.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Viestin varmistus epäonnistui.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Viesti varmistettu.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Avoinna vielä %n lohkon ajan</numerusform><numerusform>Avoinna vielä %n lohkon ajan</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Avoinna %1 asti</translation>
    </message>
    <message>
        <source>conflicted with a transaction with %1 confirmations</source>
        <translation>ristiriidassa maksutapahtumalle, jolla on %1 varmistusta</translation>
    </message>
    <message>
        <source>0/unconfirmed, %1</source>
        <translation>0/varmistamaton, %1</translation>
    </message>
    <message>
        <source>in memory pool</source>
        <translation>muistialtaassa</translation>
    </message>
    <message>
        <source>not in memory pool</source>
        <translation>ei muistialtaassa</translation>
    </message>
    <message>
        <source>abandoned</source>
        <translation>hylätty</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/vahvistamaton</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 vahvistusta</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Lähde</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Generoitu</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Lähettäjä</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>tuntematon</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Saaja</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>oma osoite</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>vain katseltava</translation>
    </message>
    <message>
        <source>label</source>
        <translation>nimi</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Krediitti</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>kypsyy %n lohkon kuluttua</numerusform><numerusform>kypsyy %n lohkon kuluttua</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>ei hyväksytty</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debiitti</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Debiitti yhteensä</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Krediitti yhteensä</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Siirtokulu</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettomäärä</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Maksutapahtuman tunnus</translation>
    </message>
    <message>
        <source>Transaction total size</source>
        <translation>Maksutapahtuman kokonaiskoko</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Kauppias</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Luotujen kolikoiden täytyy kypsyä vielä %1 lohkoa ennenkuin niitä voidaan käyttää. Luotuasi tämän lohkon, se kuulutettiin verkolle lohkoketjuun lisättäväksi. Mikäli lohko ei kuitenkaan pääse ketjuun, sen tilaksi vaihdetaan "ei hyväksytty" ja sitä ei voida käyttää. Toisinaan näin tapahtuu, jos jokin verkon toinen solmu luo lohkon lähes samanaikaisesti sinun lohkosi kanssa.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Debug tiedot</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Maksutapahtuma</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Sisääntulot</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>true</source>
        <translation>tosi</translation>
    </message>
    <message>
        <source>false</source>
        <translation>epätosi</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Tämä ruutu näyttää yksityiskohtaisen tiedon rahansiirrosta</translation>
    </message>
    <message>
        <source>Details for %1</source>
        <translation>%1:n yksityiskohdat</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Avoinna vielä %n lohkon ajan</numerusform><numerusform>Avoinna vielä %n lohkon ajan</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Avoinna %1 asti</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Varmistamaton</translation>
    </message>
    <message>
        <source>Abandoned</source>
        <translation>Hylätty</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Varmistetaan (%1 suositellusta %2 varmistuksesta)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Varmistettu (%1 varmistusta)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>Ristiriitainen</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Epäkypsä (%1 varmistusta, saatavilla %2 jälkeen)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Luotu, mutta ei hyäksytty</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Vastaanotettu osoitteella</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Vastaanotettu</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Lähetetty vastaanottajalle</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Maksu itsellesi</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Louhittu</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>vain katseltava</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(ei saatavilla)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimikettä)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Rahansiirron tila. Siirrä osoitin kentän päälle nähdäksesi vahvistusten lukumäärä.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Rahansiirron vastaanottamisen päivämäärä ja aika.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Maksutapahtuman tyyppi.</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Onko rahansiirrossa mukana ainoastaan katseltava osoite vai ei.</translation>
    </message>
    <message>
        <source>User-defined intent/purpose of the transaction.</source>
        <translation>Käyttäjän määrittämä käyttötarkoitus rahansiirrolle.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Saldoon lisätty tai siitä vähennetty määrä.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Tänään</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Tällä viikolla</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Tässä kuussa</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Viime kuussa</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Tänä vuonna</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Alue...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Vastaanotettu osoitteella</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Lähetetty vastaanottajalle</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Itsellesi</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Louhittu</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Muu</translation>
    </message>
    <message>
        <source>Enter address, transaction id, or label to search</source>
        <translation>Kirjoita osoite, siirron tunniste tai nimiö etsiäksesi</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimimäärä</translation>
    </message>
    <message>
        <source>Abandon transaction</source>
        <translation>Hylkää siirto</translation>
    </message>
    <message>
        <source>Increase transaction fee</source>
        <translation>Kasvata siirtokulun määrää</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopioi osoite</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopioi nimike</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopioi transaktion ID</translation>
    </message>
    <message>
        <source>Copy raw transaction</source>
        <translation>Kopioi rahansiirron raakavedos</translation>
    </message>
    <message>
        <source>Copy full transaction details</source>
        <translation>Kopioi rahansiirron täydet yksityiskohdat</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Muokkaa nimeä</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Näytä rahansiirron yksityiskohdat</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Vie rahansiirtohistoria</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Pilkuilla erotettu tiedosto (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Vahvistettu</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Vain katseltava</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Vienti epäonnistui</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Rahansiirron historian tallentamisessa tapahtui virhe paikkaan %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Vienti onnistui</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Rahansiirron historia tallennettiin onnistuneesti kohteeseen %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Alue:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>vastaanottaja</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Yksikkö jossa määrät näytetään. Klikkaa valitaksesi toisen yksikön.</translation>
    </message>
</context>
<context>
    <name>WalletController</name>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Lomakkoa ei ole ladattu.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Lähetä kolikoita</translation>
    </message>
    <message>
        <source>Fee bump error</source>
        <translation>Virhe nostaessa palkkiota.</translation>
    </message>
    <message>
        <source>Increasing transaction fee failed</source>
        <translation>Siirtokulun nosto epäonnistui</translation>
    </message>
    <message>
        <source>Do you want to increase the fee?</source>
        <translation>Haluatko nostaa siirtomaksua?</translation>
    </message>
    <message>
        <source>Current fee:</source>
        <translation>Nykyinen palkkio:</translation>
    </message>
    <message>
        <source>Increase:</source>
        <translation>Korota:</translation>
    </message>
    <message>
        <source>New fee:</source>
        <translation>Uusi palkkio:</translation>
    </message>
    <message>
        <source>Confirm fee bump</source>
        <translation>Vahvista palkkion korotus</translation>
    </message>
    <message>
        <source>Can't sign transaction.</source>
        <translation>Siirtoa ei voida allekirjoittaa.</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Siirtoa ei voitu tehdä</translation>
    </message>
    <message>
        <source>default wallet</source>
        <translation>oletuslompakko</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Vie</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Vie auki olevan välilehden tiedot tiedostoon</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Varmuuskopioi lompakko</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Lompakkodata (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Varmuuskopio epäonnistui</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Lompakon tallennuksessa tapahtui virhe %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Varmuuskopio Onnistui</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Lompakko tallennettiin onnistuneesti tiedostoon %1.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file %s or %s</source>
        <translation>Jaettu MIT -ohjelmistolisenssin alaisuudessa, katso mukana tuleva %s tiedosto tai %s</translation>
    </message>
    <message>
        <source>Prune configured below the minimum of %d MiB.  Please use a higher number.</source>
        <translation>Karsinta konfiguroitu alle minimin %d MiB. Käytä surempaa numeroa.</translation>
    </message>
    <message>
        <source>Prune: last wallet synchronisation goes beyond pruned data. You need to -reindex (download the whole blockchain again in case of pruned node)</source>
        <translation>Karsinta: viime lompakon synkronisointi menee karsitun datan taakse. Sinun tarvitsee ajaa -reindex (lataa koko lohkoketju uudelleen tapauksessa jossa karsiva noodi)</translation>
    </message>
    <message>
        <source>Rescans are not possible in pruned mode. You will need to use -reindex which will download the whole blockchain again.</source>
        <translation>Uudelleenskannaukset eivät ole mahdollisia karsivassa tilassa. Sinun täytyy käyttää -reindex joka lataa koko lohkoketjun uudelleen.</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occurred, see debug.log for details</source>
        <translation>Virhe: Kriittinen sisäinen virhe kohdattiin, katso debug.log lisätietoja varten</translation>
    </message>
    <message>
        <source>Pruning blockstore...</source>
        <translation>Karsitaan lohkovarastoa...</translation>
    </message>
    <message>
        <source>Unable to start HTTP server. See debug log for details.</source>
        <translation>HTTP-palvelinta ei voitu käynnistää. Katso debug-lokista lisätietoja.</translation>
    </message>
    <message>
        <source>Hashmoo Core</source>
        <translation>Hashmoo-ydin</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>%s kehittäjät</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. %s is probably already running.</source>
        <translation>Ei voida lukita data-hakemistoa %s. %s on luultavasti jo käynnissä.</translation>
    </message>
    <message>
        <source>Error reading %s! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Virhe luettaessa %s! Avaimet luetttiin oikein, mutta rahansiirtotiedot tai osoitekirjan sisältö saattavat olla puutteellisia tai vääriä.</translation>
    </message>
    <message>
        <source>Please check that your computer's date and time are correct! If your clock is wrong, %s will not work properly.</source>
        <translation>Tarkistathan että tietokoneesi päivämäärä ja kellonaika ovat oikeassa! Jos kellosi on väärässä, %s ei toimi oikein.</translation>
    </message>
    <message>
        <source>Please contribute if you find %s useful. Visit %s for further information about the software.</source>
        <translation>Ole hyvä ja avusta, jos %s on mielestäsi hyödyllinen. Vieraile %s saadaksesi lisää tietoa ohjelmistosta.</translation>
    </message>
    <message>
        <source>The block database contains a block which appears to be from the future. This may be due to your computer's date and time being set incorrectly. Only rebuild the block database if you are sure that your computer's date and time are correct</source>
        <translation>Lohkotietokanta sisältää lohkon, joka vaikuttaa olevan tulevaisuudesta. Tämä saattaa johtua tietokoneesi virheellisesti asetetuista aika-asetuksista. Rakenna lohkotietokanta uudelleen vain jos olet varma, että tietokoneesi päivämäärä ja aika ovat oikein.</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Tämä on esi-julkaistu kokeiluversio - Käyttö omalla vastuullasi - Ethän käytä louhimiseen tai kauppasovelluksiin.</translation>
    </message>
    <message>
        <source>Unable to replay blocks. You will need to rebuild the database using -reindex-chainstate.</source>
        <translation>Lohkoja ei voida uudelleenlukea. Joulut uudelleenrakentamaan tietokannan käyttämällä -reindex-chainstate -valitsinta.</translation>
    </message>
    <message>
        <source>Unable to rewind the database to a pre-fork state. You will need to redownload the blockchain</source>
        <translation>Tietokantaa ei onnistuttu palauttamaan tilaan ennen haarautumista. Lohkoketju pitää ladata uudestaan.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Varoitus: Tietoverkko ei ole sovussa! Luohijat näyttävät kokevan virhetilanteita.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Varoitus: Olemme ristiriidassa vertaisten kanssa! Sinun tulee päivittää tai toisten solmujen tulee päivitää.</translation>
    </message>
    <message>
        <source>%d of last 100 blocks have unexpected version</source>
        <translation>%d viimeisestä 100 lohkosta sisälsi odottamattoman versiotiedon</translation>
    </message>
    <message>
        <source>%s corrupt, salvage failed</source>
        <translation>%s korruptoitunut, korjaaminen epäonnistui</translation>
    </message>
    <message>
        <source>-maxmempool must be at least %d MB</source>
        <translation>-maxmempool on oltava vähintään %d MB</translation>
    </message>
    <message>
        <source>Cannot resolve -%s address: '%s'</source>
        <translation>-%s -osoitteen '%s' selvittäminen epäonnistui</translation>
    </message>
    <message>
        <source>Copyright (C) %i-%i</source>
        <translation>Tekijänoikeus (C) %i-%i</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Vioittunut lohkotietokanta havaittu</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Haluatko uudelleenrakentaa lohkotietokannan nyt?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Virhe alustaessa lohkotietokantaa</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Virhe alustaessa lompakon tietokantaympäristöä %s!</translation>
    </message>
    <message>
        <source>Error loading %s</source>
        <translation>Virhe ladattaessa %s</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet corrupted</source>
        <translation>Virhe ladattaessa %s: Lompakko vioittunut</translation>
    </message>
    <message>
        <source>Error loading %s: Wallet requires newer version of %s</source>
        <translation>Virhe ladattaessa %s: Tarvitset uudemman %s -version</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Virhe avattaessa lohkoketjua</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Virhe avattaessa lohkoindeksiä</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Varoitus: Levytila on vähissä!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Ei onnistuttu kuuntelemaan missään portissa. Käytä -listen=0 jos haluat tätä.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Tuodaan...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Virheellinen tai olematon alkulohko löydetty. Väärä data-hakemisto verkolle?</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. %s is shutting down.</source>
        <translation>Alustava järkevyyden tarkistus epäonnistui. %s sulkeutuu.</translation>
    </message>
    <message>
        <source>Invalid amount for -%s=&lt;amount&gt;: '%s'</source>
        <translation>Virheellinen määrä -%s=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -discardfee=&lt;amount&gt;: '%s'</source>
        <translation>Virheellinen määrä -discardfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -fallbackfee=&lt;amount&gt;: '%s'</source>
        <translation>Virheellinen määrä -fallbackfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Specified blocks directory "%s" does not exist.</source>
        <translation>Määrättyä lohkohakemistoa "%s" ei ole olemassa.</translation>
    </message>
    <message>
        <source>Upgrading txindex database</source>
        <translation>Päivitetään txindex -tietokantaa</translation>
    </message>
    <message>
        <source>Loading P2P addresses...</source>
        <translation>Ladataan P2P-vertaisten osoitteita...</translation>
    </message>
    <message>
        <source>Loading banlist...</source>
        <translation>Ladataan kieltolistaa...</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Ei tarpeeksi tiedostomerkintöjä vapaana.</translation>
    </message>
    <message>
        <source>Prune cannot be configured with a negative value.</source>
        <translation>Karsintaa ei voi toteuttaa negatiivisella arvolla.</translation>
    </message>
    <message>
        <source>Prune mode is incompatible with -txindex.</source>
        <translation>Karsittu tila ei ole yhteensopiva -txindex:n kanssa.</translation>
    </message>
    <message>
        <source>Replaying blocks...</source>
        <translation>Tarkastetaan lohkoja..</translation>
    </message>
    <message>
        <source>Rewinding blocks...</source>
        <translation>Varmistetaan lohkoja...</translation>
    </message>
    <message>
        <source>The source code is available from %s.</source>
        <translation>Lähdekoodi löytyy %s.</translation>
    </message>
    <message>
        <source>Transaction fee and change calculation failed</source>
        <translation>Siirtokulun ja vaihtorahan laskenta epäonnistui</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. %s is probably already running.</source>
        <translation>Kytkeytyminen kohteeseen %s ei onnistu tällä tietokoneella. %s on luultavasti jo käynnissä.</translation>
    </message>
    <message>
        <source>Unable to generate keys</source>
        <translation>Avaimia ei voitu luoda</translation>
    </message>
    <message>
        <source>Unsupported logging category %s=%s.</source>
        <translation>Lokikategoriaa %s=%s ei tueta.</translation>
    </message>
    <message>
        <source>Upgrading UTXO database</source>
        <translation>Päivitetään UTXO-tietokantaa</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Varmistetaan lohkoja...</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart %s to complete</source>
        <translation>Lompakko tarvitsee uudelleenkirjoittaa: käynnistä %s uudelleen</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Virhe: Saapuvien yhteyksien kuuntelu epäonnistui (kuuntelu palautti virheen %s)</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>Siirtomäärä on liian pieni lähetettäväksi kulun vähentämisen jälkeen.</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to go back to unpruned mode.  This will redownload the entire blockchain</source>
        <translation>Palataksesi karsimattomaan tilaan joudut uudelleenrakentamaan tietokannan -reindex -valinnalla. Tämä lataa koko lohkoketjun uudestaan.</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Virheitä tietokantaa luettaessa, ohjelma pysäytetään.</translation>
    </message>
    <message>
        <source>Error upgrading chainstate database</source>
        <translation>Virhe päivittäessä chainstate-tietokantaa</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Tietoa</translation>
    </message>
    <message>
        <source>Invalid -onion address or hostname: '%s'</source>
        <translation>Virheellinen -onion osoite tai isäntänimi: '%s'</translation>
    </message>
    <message>
        <source>Invalid -proxy address or hostname: '%s'</source>
        <translation>Virheellinen -proxy osoite tai isäntänimi: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</source>
        <translation>Kelvoton määrä argumentille -paytxfee=&lt;amount&gt;: '%s' (pitää olla vähintään %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation>Kelvoton verkkopeite määritelty argumentissa -whitelist: '%s'</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation>Pitää määritellä portti argumentilla -whitebind: '%s'</translation>
    </message>
    <message>
        <source>Reducing -maxconnections from %d to %d, because of system limitations.</source>
        <translation>Vähennetään -maxconnections arvoa %d:stä %d:hen järjestelmän rajoitusten vuoksi.</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Siirron vahvistus epäonnistui</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" does not exist</source>
        <translation>Määriteltyä lompakon hakemistoa "%s" ei ole olemassa.</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" is a relative path</source>
        <translation>Määritelty lompakkohakemisto "%s" sijaitsee suhteellisessa polussa</translation>
    </message>
    <message>
        <source>Specified -walletdir "%s" is not a directory</source>
        <translation>Määritelty -walletdir "%s" ei ole hakemisto</translation>
    </message>
    <message>
        <source>The transaction amount is too small to pay the fee</source>
        <translation>Rahansiirron määrä on liian pieni kattaakseen maksukulun</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Tämä on ohjelmistoa kokeelliseen käyttöön.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Siirtosumma liian pieni</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Rahansiirto on liian suuri maksukulukäytännölle</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Siirtosumma liian iso</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Kytkeytyminen kohteeseen %s ei onnistunut tällä tietokonella (kytkeytyminen palautti virheen %s)</translation>
    </message>
    <message>
        <source>Verifying wallet(s)...</source>
        <translation>Varmistetaan lompakko(ja)...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside wallet directory %s</source>
        <translation>Lompakko %s sijaitsee lompakkohakemiston %s ulkopuolella.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <source>Warning: unknown new rules activated (versionbit %i)</source>
        <translation>Varoitus: tuntemattomia uusia sääntöjä aktivoitu (versiobitti %i)</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Tyhjennetään kaikki rahansiirrot lompakosta....</translation>
    </message>
    <message>
        <source>-maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>-maxtxfee on asetettu erittäin suureksi! Tämänkokoisia kuluja saatetaan maksaa yhdessä rahansiirrossa.</translation>
    </message>
    <message>
        <source>This is the transaction fee you may pay when fee estimates are not available.</source>
        <translation>Tämän siirtomaksun maksat, kun siirtomaksun arviointi ei ole käytettävissä.</translation>
    </message>
    <message>
        <source>%s is set very high!</source>
        <translation>%s on asetettu todella korkeaksi!</translation>
    </message>
    <message>
        <source>Error loading wallet %s. Duplicate -wallet filename specified.</source>
        <translation>Virhe ladattaessa lompakkoa %s. -wallet -tiedostonimi esiintyy useaan kertaan.</translation>
    </message>
    <message>
        <source>Keypool ran out, please call keypoolrefill first</source>
        <translation>Avainallas tyhjentyi, ole hyvä ja kutsu keypoolrefill ensin</translation>
    </message>
    <message>
        <source>Starting network threads...</source>
        <translation>Käynnistetään verkkoa...</translation>
    </message>
    <message>
        <source>The wallet will avoid paying less than the minimum relay fee.</source>
        <translation>Lompakko välttää maksamasta alle vähimmäisen välityskulun.</translation>
    </message>
    <message>
        <source>This is the minimum transaction fee you pay on every transaction.</source>
        <translation>Tämä on jokaisesta siirrosta maksettava vähimmäismaksu.</translation>
    </message>
    <message>
        <source>This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Tämä on lähetyksestä maksettava maksu jonka maksat</translation>
    </message>
    <message>
        <source>Transaction amounts must not be negative</source>
        <translation>Lähetyksen siirtosumman tulee olla positiivinen</translation>
    </message>
    <message>
        <source>Transaction has too long of a mempool chain</source>
        <translation>Maksutapahtumalla on liian pitkä muistialtaan ketju</translation>
    </message>
    <message>
        <source>Transaction must have at least one recipient</source>
        <translation>Lähetyksessä tulee olla ainakin yksi vastaanottaja</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Tuntematon verkko -onlynet parametrina: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Lompakon saldo ei riitä</translation>
    </message>
    <message>
        <source>Fee estimation failed. Fallbackfee is disabled. Wait a few blocks or enable -fallbackfee.</source>
        <translation>Siirtomaksun arviointi epäonnistui. Odota muutama lohko tai käytä -fallbackfee -valintaa..</translation>
    </message>
    <message>
        <source>Cannot write to data directory '%s'; check permissions.</source>
        <translation>Hakemistoon '%s' ei voida kirjoittaa. Tarkista käyttöoikeudet.</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Ladataan lohkoindeksiä...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Ladataan lompakkoa...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Et voi päivittää lompakkoasi vanhempaan versioon</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Skannataan uudelleen...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Lataus on valmis</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
</context>
</TS>